import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, DollarSign, ShoppingBag, MapPin, TrendingUp } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

const VENDAS_MES = [
  { month: "Out", vendas: 42000 }, { month: "Nov", vendas: 68000 }, { month: "Dez", vendas: 55000 },
  { month: "Jan", vendas: 90000 }, { month: "Fev", vendas: 78000 }, { month: "Mar", vendas: 112000 },
];

const DESTINOS = [
  { nome: "Fernando de Noronha", vendas: 45 },
  { nome: "Gramado", vendas: 38 },
  { nome: "Cancún", vendas: 32 },
  { nome: "Salvador", vendas: 28 },
  { nome: "Paris", vendas: 22 },
];

const PERIODOS = ["Último mês", "Últimos 3 meses", "Últimos 6 meses", "Último ano"];

const Relatorios = () => {
  const navigate = useNavigate();
  const [periodo, setPeriodo] = useState("Últimos 6 meses");

  const totalVendas = "R$ 445.000";
  const totalPedidos = 165;

  return (
    <div className="min-h-screen" style={{ background: "hsl(var(--muted))", maxWidth: 480, margin: "0 auto" }}>
      <div style={{ background: "linear-gradient(160deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)", padding: "48px 20px 28px" }}>
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/admin")} style={{ background: "rgba(255,255,255,0.15)", border: "none", borderRadius: 10, padding: 8, cursor: "pointer" }}>
            <ArrowLeft size={18} color="white" />
          </button>
          <h1 style={{ color: "white", fontSize: 18, fontWeight: 700 }}>Relatório de Vendas</h1>
        </div>
      </div>

      <div style={{ padding: "16px 14px", marginTop: -16 }}>
        {/* Period filter */}
        <div className="flex items-center gap-2 mb-4 overflow-x-auto" style={{ paddingBottom: 2 }}>
          {PERIODOS.map((p) => (
            <button key={p} onClick={() => setPeriodo(p)}
              style={{
                padding: "6px 14px", borderRadius: 20, fontSize: 11, fontWeight: 700, border: "none", cursor: "pointer", whiteSpace: "nowrap",
                background: periodo === p ? "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))" : "white",
                color: periodo === p ? "white" : "hsl(var(--muted-foreground))",
                boxShadow: periodo === p ? "none" : "0 1px 4px rgba(0,0,0,0.06)",
              }}>
              {p}
            </button>
          ))}
        </div>

        {/* KPI cards */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
          <div style={{ background: "white", borderRadius: 18, padding: 16, boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}>
            <div style={{ width: 38, height: 38, borderRadius: 11, background: "hsl(155 70% 92%)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}>
              <DollarSign size={19} style={{ color: "hsl(155 70% 42%)" }} />
            </div>
            <p style={{ fontSize: 10, fontWeight: 600, color: "hsl(var(--muted-foreground))", margin: 0 }}>Total de vendas</p>
            <p style={{ fontSize: 22, fontWeight: 800, color: "hsl(var(--foreground))", margin: "4px 0 0" }}>{totalVendas}</p>
          </div>
          <div style={{ background: "white", borderRadius: 18, padding: 16, boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}>
            <div style={{ width: 38, height: 38, borderRadius: 11, background: "hsl(270 60% 94%)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}>
              <ShoppingBag size={19} style={{ color: "hsl(270 60% 50%)" }} />
            </div>
            <p style={{ fontSize: 10, fontWeight: 600, color: "hsl(var(--muted-foreground))", margin: 0 }}>Nº de pedidos</p>
            <p style={{ fontSize: 22, fontWeight: 800, color: "hsl(var(--foreground))", margin: "4px 0 0" }}>{totalPedidos}</p>
          </div>
        </div>

        {/* Sales chart */}
        <div style={{ background: "white", borderRadius: 18, padding: "16px 8px 8px 0", boxShadow: "0 4px 20px rgba(0,0,0,0.06)", marginBottom: 16 }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, color: "hsl(var(--foreground))", marginLeft: 16, marginBottom: 12 }}>Vendas por mês</h3>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={VENDAS_MES}>
              <defs>
                <linearGradient id="colorV" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(38 85% 48%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(38 85% 48%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214 20% 93%)" vertical={false} />
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "hsl(215 15% 52%)", fontSize: 11, fontWeight: 600 }} />
              <YAxis hide />
              <Tooltip contentStyle={{ background: "white", border: "1px solid hsl(214 20% 90%)", borderRadius: 10, fontSize: 12, fontWeight: 600 }} formatter={(v: number) => [`R$ ${(v / 1000).toFixed(0)}K`, ""]} />
              <Area type="monotone" dataKey="vendas" stroke="hsl(38 85% 48%)" strokeWidth={2.5} fill="url(#colorV)" dot={false} activeDot={{ r: 5, fill: "hsl(38 85% 48%)", stroke: "white", strokeWidth: 2 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Top destinations */}
        <div style={{ background: "white", borderRadius: 18, padding: 16, boxShadow: "0 4px 20px rgba(0,0,0,0.06)", marginBottom: 16 }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 12 }}>Destinos mais vendidos</h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={DESTINOS} layout="vertical">
              <XAxis type="number" hide />
              <YAxis type="category" dataKey="nome" axisLine={false} tickLine={false} tick={{ fill: "hsl(215 15% 52%)", fontSize: 11, fontWeight: 600 }} width={130} />
              <Tooltip contentStyle={{ background: "white", border: "1px solid hsl(214 20% 90%)", borderRadius: 10, fontSize: 12, fontWeight: 600 }} formatter={(v: number) => [`${v} vendas`, ""]} />
              <Bar dataKey="vendas" fill="hsl(38 85% 48%)" radius={[0, 8, 8, 0]} barSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Destinations list */}
        <div style={{ background: "white", borderRadius: 18, overflow: "hidden", boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}>
          <h3 style={{ fontSize: 13, fontWeight: 700, color: "hsl(var(--foreground))", padding: "16px 16px 8px" }}>Ranking de destinos</h3>
          {DESTINOS.map((d, i) => (
            <div key={d.nome} style={{ display: "flex", alignItems: "center", padding: "12px 16px", gap: 12, borderBottom: i < DESTINOS.length - 1 ? "1px solid hsl(var(--border))" : "none" }}>
              <span style={{ width: 24, height: 24, borderRadius: 8, background: i < 3 ? "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))" : "hsl(var(--muted))", color: i < 3 ? "white" : "hsl(var(--muted-foreground))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800 }}>
                {i + 1}
              </span>
              <MapPin size={14} style={{ color: "hsl(var(--muted-foreground))" }} />
              <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: "hsl(var(--foreground))" }}>{d.nome}</span>
              <span style={{ fontSize: 12, fontWeight: 700, color: "hsl(var(--primary))" }}>{d.vendas} vendas</span>
            </div>
          ))}
        </div>

        <div style={{ height: 24 }} />
      </div>
    </div>
  );
};

export default Relatorios;
