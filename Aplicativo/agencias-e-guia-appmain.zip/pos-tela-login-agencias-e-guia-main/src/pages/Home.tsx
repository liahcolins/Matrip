import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Home as HomeIcon,
  Plane,
  CalendarCheck,
  User,
  Bell,
  FileText,
  Clock,
  History,
  ChevronRight,
  MapPin,
  TrendingUp,
  Users,
  CheckCircle2,
  PlusCircle,
  ArrowUpRight,
  FileBadge,
  FileSignature,
  X,
  Eye,
  Download,
  PenLine,
  Search,
  Filter,
  Calendar,
  DollarSign,
  Phone,
  Mail,
  Star,
  ChevronDown,
  ArrowLeft,
  Hotel,
  Car,
  CreditCard,
  AlertCircle,
  CheckCircle,
  XCircle,
  UserPlus,
  IdCard,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import logoMatrip from "@/assets/logo_matrip.png";

/* ─── MOCK DATA ─── */
const KPI_DATA = [
  { label: "Solicitações", value: 128, icon: FileText, color: "210 90% 56%", bg: "210 90% 95%" },
  { label: "Em andamento", value: 34, icon: Plane, color: "155 70% 42%", bg: "155 70% 93%" },
  { label: "Satisfeitos", value: "97%", icon: Users, color: "270 60% 58%", bg: "270 60% 94%" },
  { label: "Concluídas", value: 412, icon: CheckCircle2, color: "30 90% 50%", bg: "30 90% 93%" },
];

const RECENT_TRIPS = [
  { id: 1, dest: "São Paulo → Carolina", date: "12 Mar 2025", status: "aprovado", pax: "Lucas Mendes" },
  { id: 2, dest: "Curitiba → Carolina", date: "15 Mar 2025", status: "em andamento", pax: "Ana Souza" },
  { id: 3, dest: "Rio de Janeiro → Tutóia", date: "18 Mar 2025", status: "pendente", pax: "Carlos Lima" },
  { id: 4, dest: "Belo Horizonte → Barreirinhas", date: "20 Mar 2025", status: "concluído", pax: "Mariana Reis" },
  { id: 5, dest: "Porto Alegre → Raposa", date: "22 Mar 2025", status: "pendente", pax: "SOLtur Santos" },
];

const ALL_TRIPS = [
  ...RECENT_TRIPS,
  { id: 6, dest: "São Paulo → Barreirinhas", date: "05 Fev 2025", status: "concluído", pax: "Rafael Costa" },
  { id: 7, dest: "Recife → Carolina", date: "28 Jan 2025", status: "concluído", pax: "Fernanda Oliveira" },
  { id: 8, dest: "Manaus → Raposa", date: "15 Jan 2025", status: "cancelado", pax: "Pedro Alves" },
  { id: 9, dest: "Brasília → Tutóia", date: "10 Jan 2025", status: "concluído", pax: "Juliana Silva" },
  { id: 10, dest: "Salvador → Carolina", date: "02 Dez 2024", status: "concluído", pax: "Marcos Pereira" },
];

const CHART_DATA = [
  { month: "Out", viagens: 28 },
  { month: "Nov", viagens: 42 },
  { month: "Dez", viagens: 36 },
  { month: "Jan", viagens: 58 },
  { month: "Fev", viagens: 49 },
  { month: "Mar", viagens: 72 },
];

const STATUS_STYLES: Record<string, { bg: string; text: string; label: string }> = {
  pendente: { bg: "45 100% 90%", text: "45 90% 38%", label: "Pendente" },
  aprovado: { bg: "210 90% 92%", text: "210 80% 42%", label: "Aprovado" },
  "em andamento": { bg: "155 70% 90%", text: "155 70% 34%", label: "Em andamento" },
  concluído: { bg: "270 60% 92%", text: "270 55% 45%", label: "Concluído" },
  cancelado: { bg: "0 70% 92%", text: "0 70% 45%", label: "Cancelado" },
};

const CONTRACTS_SIGNED = [
  { id: 1, title: "Contrato de Transporte Aéreo", parceiro: "LATAM Airlines", date: "05 Jan 2025", value: "R$ 48.000", pdf: null },
  { id: 2, title: "Acordo de Hospedagem Corporativa", parceiro: "Marriott SP", date: "18 Fev 2025", value: "R$ 22.500", pdf: null },
  { id: 3, title: "Serviços de Transfer Executivo", parceiro: "VIP Transfer", date: "02 Mar 2025", value: "R$ 8.200", pdf: null },
];

const CONTRACTS_PENDING = [
  { id: 4, title: "Contrato de Prestação de Serviços CVC", parceiro: "CVC Corp", date: "Vence 25 Mar 2025", value: "R$ 31.000", pdf: "/Contrato_prestacao_de_servico_CVC.pdf" },
  { id: 5, title: "Pacote de Viagens Internacionais", parceiro: "CWT Travel", date: "Vence 01 Abr 2025", value: "R$ 95.000", pdf: null },
];

/* ─── BOOKINGS MOCK DATA ─── */
const BOOKINGS = [
  { id: 1, type: "hotel", title: "Pousada Encanto Carolina", guest: "Lucas Mendes", checkin: "14 Mar 2025", checkout: "18 Mar 2025", status: "confirmado", value: "R$ 2.400" },
  { id: 2, type: "flight", title: "Voo SP → SLZ", guest: "Ana Souza", checkin: "15 Mar 2025", checkout: "", status: "confirmado", value: "R$ 1.850" },
  { id: 3, type: "transfer", title: "Transfer Aeroporto → Hotel", guest: "Carlos Lima", checkin: "18 Mar 2025", checkout: "", status: "pendente", value: "R$ 180" },
  { id: 4, type: "hotel", title: "Hotel Lençóis Barreirinhas", guest: "Mariana Reis", checkin: "20 Mar 2025", checkout: "24 Mar 2025", status: "confirmado", value: "R$ 3.200" },
  { id: 5, type: "flight", title: "Voo POA → SLZ", guest: "SOLtur Santos", checkin: "22 Mar 2025", checkout: "", status: "pendente", value: "R$ 2.100" },
];

const BOOKING_ICONS: Record<string, typeof Hotel> = {
  hotel: Hotel,
  flight: Plane,
  transfer: Car,
};

const BOOKING_STATUS: Record<string, { bg: string; text: string; label: string }> = {
  confirmado: { bg: "155 70% 90%", text: "155 70% 34%", label: "Confirmado" },
  pendente: { bg: "45 100% 90%", text: "45 90% 38%", label: "Pendente" },
  cancelado: { bg: "0 70% 92%", text: "0 70% 45%", label: "Cancelado" },
};

type Tab = "home" | "trips" | "bookings" | "profile";
type ModalView = null | "newTrip" | "activeTrips" | "history" | "registerTourist";

interface Notification {
  id: number;
  type: "success" | "info" | "warning" | "error";
  title: string;
  description: string;
  time: Date;
  read: boolean;
}

const NOTIFICATION_ICONS: Record<string, { color: string; bg: string }> = {
  success: { color: "155 70% 34%", bg: "155 70% 90%" },
  info: { color: "210 90% 42%", bg: "210 90% 92%" },
  warning: { color: "45 90% 38%", bg: "45 100% 88%" },
  error: { color: "0 70% 45%", bg: "0 70% 90%" },
};

const INITIAL_NOTIFICATIONS: Notification[] = [
  { id: 1, type: "info", title: "Bem-vindo ao Matrip", description: "Seu painel corporativo está pronto para uso.", time: new Date(Date.now() - 3600000), read: false },
  { id: 2, type: "success", title: "Contrato assinado", description: "Contrato de Transporte Aéreo com LATAM Airlines foi assinado.", time: new Date(Date.now() - 7200000), read: true },
  { id: 3, type: "warning", title: "Contrato pendente", description: "Contrato CVC Corp vence em 25 Mar 2025.", time: new Date(Date.now() - 86400000), read: false },
];

const HomeScreen = () => {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [loaded, setLoaded] = useState(false);
  const [showContracts, setShowContracts] = useState(false);
  const [contractTab, setContractTab] = useState<"signed" | "pending">("pending");
  const [selectedContract, setSelectedContract] = useState<typeof CONTRACTS_PENDING[0] | null>(null);
  const [signConfirm, setSignConfirm] = useState(false);
  const [modalView, setModalView] = useState<ModalView>(null);
  const [historyFilter, setHistoryFilter] = useState("todos");
  const [searchQuery, setSearchQuery] = useState("");
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);
  const [showNotifications, setShowNotifications] = useState(false);
  const navigate = useNavigate();

  const addNotification = (type: Notification["type"], title: string, description: string) => {
    const newNotif: Notification = {
      id: Date.now(),
      type,
      title,
      description,
      time: new Date(),
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const clearNotification = (id: number) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    addNotification("info", "Notificação removida", "Uma notificação foi excluída.");
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  const formatTime = (date: Date) => {
    const diff = Date.now() - date.getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "Agora";
    if (mins < 60) return `${mins}min atrás`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h atrás`;
    const days = Math.floor(hours / 24);
    return `${days}d atrás`;
  };

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 80);
    return () => clearTimeout(t);
  }, []);

  const activeTrips = ALL_TRIPS.filter((t) => t.status === "em andamento" || t.status === "pendente" || t.status === "aprovado");
  const filteredHistory = ALL_TRIPS.filter((t) => {
    const matchStatus = historyFilter === "todos" || t.status === historyFilter;
    const matchSearch = searchQuery === "" || t.dest.toLowerCase().includes(searchQuery.toLowerCase()) || t.pax.toLowerCase().includes(searchQuery.toLowerCase());
    return matchStatus && matchSearch;
  });

  /* ─── SLIDE PANEL COMPONENT ─── */
  const SlidePanel = ({ show, onClose, title, subtitle, icon: PanelIcon, children }: {
    show: boolean; onClose: () => void; title: string; subtitle: string; icon: typeof FileText; children: React.ReactNode;
  }) => {
    if (!show) return null;
    return (
      <div
        style={{ position: "fixed", inset: 0, zIndex: 100, display: "flex", alignItems: "flex-end", background: "rgba(0,0,0,0.45)" }}
        onClick={onClose}
      >
        <div
          style={{
            width: "100%", maxWidth: 480, margin: "0 auto", background: "white",
            borderRadius: "24px 24px 0 0", maxHeight: "90vh", display: "flex", flexDirection: "column",
            overflow: "hidden", animation: "slideUp 0.3s ease-out"
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <div style={{
            background: "linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
            padding: "20px 20px 18px", display: "flex", alignItems: "center", justifyContent: "space-between"
          }}>
            <div className="flex items-center gap-3">
              <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 10, padding: 8, display: "flex" }}>
                <PanelIcon size={20} color="white" />
              </div>
              <div>
                <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 10, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", margin: 0 }}>{subtitle}</p>
                <h3 style={{ color: "white", fontSize: 17, fontWeight: 800, margin: 0 }}>{title}</h3>
              </div>
            </div>
            <button onClick={onClose} style={{ background: "rgba(255,255,255,0.18)", border: "none", borderRadius: 10, padding: 7, cursor: "pointer", display: "flex" }}>
              <X size={18} color="white" />
            </button>
          </div>
          <div style={{ overflowY: "auto", flex: 1 }}>
            {children}
          </div>
        </div>
      </div>
    );
  };

  /* ─── NEW TRIP FORM ─── */
  const NewTripForm = () => {
    const [formData, setFormData] = useState({ origin: "", destination: "", date: "", returnDate: "", pax: "", notes: "" });
    return (
      <div style={{ padding: "20px 16px", display: "flex", flexDirection: "column", gap: 14 }}>
        {[
          { label: "Origem", key: "origin", placeholder: "Ex: São Paulo", icon: MapPin },
          { label: "Destino", key: "destination", placeholder: "Ex: Carolina", icon: MapPin },
          { label: "Data de ida", key: "date", placeholder: "DD/MM/AAAA", icon: Calendar, type: "date" },
          { label: "Data de volta", key: "returnDate", placeholder: "DD/MM/AAAA", icon: Calendar, type: "date" },
          { label: "Passageiro", key: "pax", placeholder: "Nome do passageiro", icon: User },
        ].map((field) => (
          <div key={field.key}>
            <label style={{ fontSize: 12, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 6, display: "block" }}>
              {field.label}
            </label>
            <div style={{
              display: "flex", alignItems: "center", gap: 10, background: "hsl(var(--muted))",
              borderRadius: 12, padding: "0 14px", border: "1px solid hsl(var(--border))"
            }}>
              <field.icon size={16} style={{ color: "hsl(var(--muted-foreground))", flexShrink: 0 }} />
              <input
                type={field.type || "text"}
                placeholder={field.placeholder}
                value={(formData as any)[field.key]}
                onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                style={{
                  flex: 1, padding: "12px 0", border: "none", background: "transparent",
                  fontSize: 13, fontWeight: 500, color: "hsl(var(--foreground))", outline: "none"
                }}
              />
            </div>
          </div>
        ))}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 6, display: "block" }}>Observações</label>
          <textarea
            placeholder="Informações adicionais..."
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            rows={3}
            style={{
              width: "100%", padding: "12px 14px", borderRadius: 12, border: "1px solid hsl(var(--border))",
              background: "hsl(var(--muted))", fontSize: 13, fontWeight: 500, color: "hsl(var(--foreground))",
              outline: "none", resize: "none", fontFamily: "inherit"
            }}
          />
        </div>
        <button
          onClick={() => {
            addNotification("success", "Solicitação enviada", `Nova solicitação de viagem: ${formData.origin || "Origem"} → ${formData.destination || "Destino"}`);
            setModalView(null);
          }}
          style={{
            width: "100%", background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))",
            color: "white", border: "none", borderRadius: 14, padding: "14px 0", fontSize: 14, fontWeight: 800,
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
            boxShadow: "0 6px 20px hsl(var(--primary) / 0.35)", marginTop: 4
          }}
        >
          <PlusCircle size={17} /> Enviar solicitação
        </button>
        <div style={{ height: 16 }} />
      </div>
    );
  };

  /* ─── REGISTER TOURIST FORM ─── */ 
  const RegisterTouristForm = ({ onClose }: { onClose: () => void }) => {
    const [form, setForm] = useState({
      name: "", birthDate: "", document: "", email: "", phone: "", destination: "", tripDate: "", notes: ""
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [submitted, setSubmitted] = useState(false);

    const validate = () => {
      const errs: Record<string, string> = {};
      if (!form.name.trim()) errs.name = "Nome é obrigatório";
      if (!form.birthDate) errs.birthDate = "Data de nascimento é obrigatória";
      if (!form.document.trim()) errs.document = "Documento é obrigatório";
      else if (form.document.replace(/\D/g, "").length < 9) errs.document = "Documento inválido";
      if (!form.email.trim()) errs.email = "E-mail é obrigatório";
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.email = "E-mail inválido";
      if (!form.phone.trim()) errs.phone = "Telefone é obrigatório";
      if (!form.destination.trim()) errs.destination = "Destino é obrigatório";
      if (!form.tripDate) errs.tripDate = "Data da viagem é obrigatória";
      return errs;
    };

    const handleSubmit = () => {
      const errs = validate();
      if (Object.keys(errs).length > 0) { setErrors(errs); return; }
      addNotification("success", "Turista cadastrado", `O turista ${form.name} foi cadastrado com sucesso.`);
      setSubmitted(true);
      setTimeout(() => { onClose(); setSubmitted(false); }, 2000);
    };

    if (submitted) {
      return (
        <div style={{ padding: "60px 20px", textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
          <div style={{ width: 64, height: 64, borderRadius: "50%", background: "linear-gradient(135deg, hsl(155 70% 42%), hsl(155 70% 55%))", display: "flex", alignItems: "center", justifyContent: "center", animation: "slideUp 0.4s ease-out" }}>
            <CheckCircle2 size={32} color="white" />
          </div>
          <h3 style={{ fontSize: 18, fontWeight: 800, color: "hsl(var(--foreground))", margin: 0 }}>Turista cadastrado!</h3>
          <p style={{ fontSize: 13, color: "hsl(var(--muted-foreground))", margin: 0 }}>O cadastro de {form.name} foi realizado com sucesso.</p>
        </div>
      );
    }

    const fields = [
      { key: "name", label: "Nome completo", placeholder: "Ex: SOLtur da Silva", icon: User, type: "text" },
      { key: "birthDate", label: "Data de nascimento", placeholder: "", icon: Calendar, type: "date" },
      { key: "document", label: "Documento (RG ou CPF)", placeholder: "000.000.000-00", icon: IdCard, type: "text" },
      { key: "email", label: "E-mail", placeholder: "email@exemplo.com", icon: Mail, type: "email" },
      { key: "phone", label: "Telefone de contato", placeholder: "(00) 00000-0000", icon: Phone, type: "tel" },
      { key: "destination", label: "Destino da viagem", placeholder: "Ex: Carolina - MA", icon: MapPin, type: "text" },
      { key: "tripDate", label: "Data prevista para viagem", placeholder: "", icon: Calendar, type: "date" },
    ];

    return (
      <div style={{ padding: "20px 16px", display: "flex", flexDirection: "column", gap: 14 }}>
        {fields.map((field) => (
          <div key={field.key}>
            <label style={{ fontSize: 12, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 6, display: "block" }}>
              {field.label} <span style={{ color: "hsl(0 70% 50%)" }}>*</span>
            </label>
            <div style={{
              display: "flex", alignItems: "center", gap: 10, background: "hsl(var(--muted))",
              borderRadius: 12, padding: "0 14px",
              border: errors[field.key] ? "1.5px solid hsl(0 70% 55%)" : "1px solid hsl(var(--border))",
              transition: "border-color 0.2s"
            }}>
              <field.icon size={16} style={{ color: errors[field.key] ? "hsl(0 70% 55%)" : "hsl(var(--muted-foreground))", flexShrink: 0 }} />
              <input
                type={field.type}
                placeholder={field.placeholder}
                value={(form as any)[field.key]}
                onChange={(e) => {
                  setForm({ ...form, [field.key]: e.target.value });
                  if (errors[field.key]) setErrors({ ...errors, [field.key]: "" });
                }}
                style={{ flex: 1, padding: "12px 0", border: "none", background: "transparent", fontSize: 13, fontWeight: 500, color: "hsl(var(--foreground))", outline: "none" }}
              />
            </div>
            {errors[field.key] && (
              <p style={{ fontSize: 11, color: "hsl(0 70% 50%)", margin: "4px 0 0", fontWeight: 600 }}>{errors[field.key]}</p>
            )}
          </div>
        ))}
        <div>
          <label style={{ fontSize: 12, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 6, display: "block" }}>
            Observações <span style={{ fontSize: 10, fontWeight: 500, color: "hsl(var(--muted-foreground))" }}>(opcional)</span>
          </label>
          <textarea
            placeholder="Informações adicionais sobre o turista..."
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            rows={3}
            style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--muted))", fontSize: 13, fontWeight: 500, color: "hsl(var(--foreground))", outline: "none", resize: "none", fontFamily: "inherit" }}
          />
        </div>
        <button
          onClick={handleSubmit}
          style={{
            width: "100%", background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))",
            color: "white", border: "none", borderRadius: 14, padding: "14px 0", fontSize: 14, fontWeight: 800,
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
            boxShadow: "0 6px 20px hsl(var(--primary) / 0.35)", marginTop: 4
          }}
        >
          <UserPlus size={17} /> Cadastrar turista
        </button>
        <div style={{ height: 16 }} />
      </div>
    );
  };

  /* ─── TRIP LIST (used for active and history) ─── */
  const TripList = ({ trips }: { trips: typeof ALL_TRIPS }) => (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {trips.length === 0 ? (
        <div style={{ textAlign: "center", padding: "40px 0", color: "hsl(var(--muted-foreground))" }}>
          <Plane size={40} style={{ opacity: 0.3, margin: "0 auto 12px" }} />
          <p style={{ fontSize: 14, fontWeight: 600 }}>Nenhuma viagem encontrada</p>
        </div>
      ) : (
        trips.map((trip) => {
          const status = STATUS_STYLES[trip.status] || STATUS_STYLES.pendente;
          return (
            <div key={trip.id} style={{
              display: "flex", alignItems: "center", gap: 12, background: "white",
              borderRadius: 16, padding: "14px 16px", boxShadow: "0 2px 10px rgba(0,0,0,0.05)",
              cursor: "pointer", transition: "transform 0.15s"
            }}>
              <div style={{
                width: 42, height: 42, borderRadius: 12, background: `hsl(${status.bg})`,
                display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0
              }}>
                <MapPin size={18} style={{ color: `hsl(${status.text})` }} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontWeight: 700, fontSize: 13, color: "hsl(var(--foreground))", margin: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {trip.dest}
                </p>
                <p style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", margin: "2px 0 0", display: "flex", alignItems: "center", gap: 4 }}>
                  <Clock size={10} /> {trip.date} · {trip.pax}
                </p>
              </div>
              <span style={{
                fontSize: 10, fontWeight: 700, color: `hsl(${status.text})`,
                background: `hsl(${status.bg})`, borderRadius: 20, padding: "3px 10px",
                whiteSpace: "nowrap", flexShrink: 0
              }}>
                {status.label}
              </span>
            </div>
          );
        })
      )}
    </div>
  );

  /* ─── TAB CONTENT: TRIPS ─── */
  const TripsTab = () => (
    <div style={{ flex: 1, overflowY: "auto", paddingBottom: 88 }}>
      <div style={{
        background: "linear-gradient(160deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
        padding: "56px 20px 28px", position: "relative", overflow: "hidden"
      }}>
        <div style={{ position: "absolute", top: -50, right: -50, width: 200, height: 200, borderRadius: "50%", background: "rgba(255,255,255,0.07)" }} />
        <h1 style={{ color: "white", fontSize: 22, fontWeight: 800, margin: 0 }}>Viagens</h1>
        <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, margin: "4px 0 0" }}>Gerencie todas as suas viagens</p>
      </div>
      <div style={{ padding: "0 14px", marginTop: 12 }}>
        {/* Search */}
        <div style={{
          display: "flex", alignItems: "center", gap: 10, background: "white", borderRadius: 14,
          padding: "0 14px", boxShadow: "0 4px 20px rgba(0,0,0,0.08)", marginBottom: 16
        }}>
          <Search size={16} style={{ color: "hsl(var(--muted-foreground))" }} />
          <input
            placeholder="Buscar viagem..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              flex: 1, padding: "13px 0", border: "none", background: "transparent",
              fontSize: 13, fontWeight: 500, color: "hsl(var(--foreground))", outline: "none"
            }}
          />
        </div>
        {/* Quick stats */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 }}>
          {[
            { label: "Ativas", value: activeTrips.length, color: "155 70% 42%", bg: "155 70% 93%" },
            { label: "Pendentes", value: ALL_TRIPS.filter(t => t.status === "pendente").length, color: "45 90% 38%", bg: "45 100% 90%" },
            { label: "Total", value: ALL_TRIPS.length, color: "210 90% 56%", bg: "210 90% 95%" },
          ].map((s) => (
            <div key={s.label} style={{
              background: "white", borderRadius: 14, padding: "12px", textAlign: "center",
              boxShadow: "0 2px 10px rgba(0,0,0,0.05)"
            }}>
              <p style={{ fontSize: 20, fontWeight: 800, color: `hsl(${s.color})`, margin: 0 }}>{s.value}</p>
              <p style={{ fontSize: 10, fontWeight: 600, color: "hsl(var(--muted-foreground))", margin: "2px 0 0" }}>{s.label}</p>
            </div>
          ))}
        </div>
        {/* Trip list */}
        <h3 style={{ fontSize: 14, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 10 }}>Todas as viagens</h3>
        <TripList trips={ALL_TRIPS.filter(t => searchQuery === "" || t.dest.toLowerCase().includes(searchQuery.toLowerCase()) || t.pax.toLowerCase().includes(searchQuery.toLowerCase()))} />
        {/* Add trip button */}
        <button
          onClick={() => setModalView("newTrip")}
          style={{
            width: "100%", marginTop: 16, background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))",
            color: "white", border: "none", borderRadius: 14, padding: "14px 0", fontSize: 14, fontWeight: 800,
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
            boxShadow: "0 6px 20px hsl(var(--primary) / 0.35)"
          }}
        >
          <PlusCircle size={17} /> Nova viagem
        </button>
        <div style={{ height: 16 }} />
      </div>
    </div>
  );

  /* ─── TAB CONTENT: BOOKINGS ─── */
  const BookingsTab = () => (
    <div style={{ flex: 1, overflowY: "auto", paddingBottom: 88 }}>
      <div style={{
        background: "linear-gradient(160deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
        padding: "56px 20px 36px", position: "relative", overflow: "hidden"
      }}>
        <div style={{ position: "absolute", top: -50, right: -50, width: 200, height: 200, borderRadius: "50%", background: "rgba(255,255,255,0.07)" }} />
        <h1 style={{ color: "white", fontSize: 22, fontWeight: 800, margin: 0 }}>Reservas</h1>
        <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, margin: "4px 0 0" }}>Acompanhe suas reservas e hospedagens</p>
      </div>
      <div style={{ padding: "0 14px", marginTop: 12 }}>
        {/* Summary cards */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
          {[
            { label: "Confirmadas", value: BOOKINGS.filter(b => b.status === "confirmado").length, icon: CheckCircle, color: "155 70% 42%", bg: "155 70% 93%" },
            { label: "Pendentes", value: BOOKINGS.filter(b => b.status === "pendente").length, icon: AlertCircle, color: "45 90% 38%", bg: "45 100% 90%" },
          ].map((s) => (
            <div key={s.label} style={{
              background: "white", borderRadius: 16, padding: "16px 14px",
              boxShadow: "0 4px 20px rgba(0,0,0,0.07)", display: "flex", alignItems: "center", gap: 12
            }}>
              <div style={{
                width: 40, height: 40, borderRadius: 12, background: `hsl(${s.bg})`,
                display: "flex", alignItems: "center", justifyContent: "center"
              }}>
                <s.icon size={18} style={{ color: `hsl(${s.color})` }} />
              </div>
              <div>
                <p style={{ fontSize: 22, fontWeight: 800, color: "hsl(var(--foreground))", margin: 0, lineHeight: 1 }}>{s.value}</p>
                <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted-foreground))", margin: "2px 0 0" }}>{s.label}</p>
              </div>
            </div>
          ))}
        </div>
        {/* Booking list */}
        <h3 style={{ fontSize: 14, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 10 }}>Suas reservas</h3>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {BOOKINGS.map((booking) => {
            const BookingIcon = BOOKING_ICONS[booking.type] || Hotel;
            const bStatus = BOOKING_STATUS[booking.status] || BOOKING_STATUS.pendente;
            return (
              <div key={booking.id} style={{
                background: "white", borderRadius: 16, padding: "16px",
                boxShadow: "0 2px 10px rgba(0,0,0,0.05)", cursor: "pointer"
              }}>
                <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                  <div style={{
                    width: 44, height: 44, borderRadius: 12, background: "hsl(var(--matrip-light))",
                    display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0
                  }}>
                    <BookingIcon size={20} style={{ color: "hsl(var(--primary))" }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontWeight: 700, fontSize: 13, color: "hsl(var(--foreground))", margin: 0 }}>{booking.title}</p>
                    <p style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", margin: "3px 0 0" }}>
                      <User size={10} style={{ display: "inline", verticalAlign: "middle", marginRight: 3 }} />
                      {booking.guest}
                    </p>
                  </div>
                  <span style={{
                    fontSize: 10, fontWeight: 700, color: `hsl(${bStatus.text})`,
                    background: `hsl(${bStatus.bg})`, borderRadius: 20, padding: "3px 10px", whiteSpace: "nowrap"
                  }}>
                    {bStatus.label}
                  </span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 12, paddingTop: 10, borderTop: "1px solid hsl(var(--border))" }}>
                  <span style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", display: "flex", alignItems: "center", gap: 4 }}>
                    <Calendar size={10} /> {booking.checkin}{booking.checkout ? ` → ${booking.checkout}` : ""}
                  </span>
                  <span style={{ fontSize: 13, fontWeight: 800, color: "hsl(var(--foreground))" }}>{booking.value}</span>
                </div>
              </div>
            );
          })}
        </div>
        <div style={{ height: 16 }} />
      </div>
    </div>
  );

  /* ─── TAB CONTENT: PROFILE ─── */
  const ProfileTab = () => (
    <div style={{ flex: 1, overflowY: "auto", paddingBottom: 88 }}>
      <div style={{
        background: "linear-gradient(160deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
        padding: "56px 20px 52px", position: "relative", overflow: "hidden", textAlign: "center"
      }}>
        <div style={{ position: "absolute", top: -50, right: -50, width: 200, height: 200, borderRadius: "50%", background: "rgba(255,255,255,0.07)" }} />
        <div style={{
          width: 72, height: 72, borderRadius: "50%", background: "rgba(255,255,255,0.2)",
          border: "3px solid rgba(255,255,255,0.4)", display: "flex", alignItems: "center", justifyContent: "center",
          margin: "0 auto 12px", cursor: "pointer"
        }} onClick={() => navigate("/profile")}>
          <User size={32} color="white" />
        </div>
        <h2 style={{ color: "white", fontSize: 18, fontWeight: 800, margin: 0 }}>Soltur Viagens</h2>
        <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, margin: "4px 0 0" }}>soltur@matrip.com.br</p>
      </div>
      <div style={{ padding: "0 14px", marginTop: 12 }}>
        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 20 }}>
          {[
            { label: "Viagens", value: "412" },
            { label: "Reservas", value: "89" },
            { label: "Avaliação", value: "4.9" },
          ].map((s) => (
            <div key={s.label} style={{
              background: "white", borderRadius: 14, padding: "14px", textAlign: "center",
              boxShadow: "0 4px 20px rgba(0,0,0,0.07)"
            }}>
              <p style={{ fontSize: 20, fontWeight: 800, color: "hsl(var(--primary))", margin: 0 }}>{s.value}</p>
              <p style={{ fontSize: 10, fontWeight: 600, color: "hsl(var(--muted-foreground))", margin: "2px 0 0" }}>{s.label}</p>
            </div>
          ))}
        </div>
        {/* Menu items */}
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {[
            { icon: User, label: "Dados pessoais", desc: "Edite suas informações", onClick: () => navigate("/profile") },
            { icon: FileSignature, label: "Contratos", desc: "Gerencie seus documentos", onClick: () => { setShowContracts(true); setActiveTab("home"); } },
            { icon: CreditCard, label: "Pagamentos", desc: "Formas de pagamento" },
            { icon: Bell, label: "Notificações", desc: "Preferências de notificação" },
            { icon: Star, label: "Avaliações", desc: "Suas avaliações de serviços" },
          ].map((item, i) => (
            <button
              key={i}
              onClick={item.onClick}
              style={{
                display: "flex", alignItems: "center", gap: 12, padding: "14px 16px",
                borderRadius: 14, border: "1px solid hsl(var(--border))", background: "white",
                cursor: "pointer", textAlign: "left", boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                transition: "transform 0.15s"
              }}
            >
              <div style={{
                width: 40, height: 40, borderRadius: 12, background: "hsl(var(--matrip-light))",
                display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0
              }}>
                <item.icon size={18} style={{ color: "hsl(var(--primary))" }} />
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontWeight: 700, fontSize: 13, margin: 0, color: "hsl(var(--foreground))" }}>{item.label}</p>
                <p style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", margin: "2px 0 0" }}>{item.desc}</p>
              </div>
              <ChevronRight size={16} style={{ color: "hsl(var(--muted-foreground))" }} />
            </button>
          ))}
        </div>
        <div style={{ height: 16 }} />
      </div>
    </div>
  );

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: "hsl(var(--muted))", maxWidth: 480, margin: "0 auto", position: "relative",
        opacity: loaded ? 1 : 0, transform: loaded ? "translateY(0)" : "translateY(12px)",
        transition: "opacity 0.5s ease-out, transform 0.5s ease-out"
      }}
    >
      {/* ─── HOME TAB CONTENT ─── */}
      {activeTab === "home" && (
        <>
          {/* HEADER */}
          <div style={{
            background: "linear-gradient(160deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
            padding: "56px 20px 52px", position: "relative", overflow: "hidden"
          }}>
            <div style={{ position: "absolute", top: -50, right: -50, width: 200, height: 200, borderRadius: "50%", background: "rgba(255,255,255,0.07)" }} />
            <div style={{ position: "absolute", bottom: -30, left: -20, width: 120, height: 120, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />
            <div className="flex items-center justify-between relative z-10">
              <div className="flex items-center gap-2.5">
                <img src={logoMatrip} alt="Matrip" className="w-14 h-14 rounded-2xl bg-white/90 p-1 shadow-md" />
                <div>
                  <span style={{ color: "rgba(255,255,255,0.65)", fontSize: 10, fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase" }}>
                    Matrip Corporate
                  </span>
                  <h1 style={{ color: "white", fontSize: 19, fontWeight: 700, lineHeight: 1.25, marginTop: 1 }}>
                    Olá, Soltur
                  </h1>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => setShowNotifications(true)} style={{ background: "rgba(255,255,255,0.14)", border: "none", borderRadius: 12, padding: 8, cursor: "pointer", position: "relative" }}>
                  <Bell size={19} color="white" />
                  {unreadCount > 0 && (
                    <span style={{ position: "absolute", top: 3, right: 3, minWidth: 16, height: 16, borderRadius: 10, background: "#ef4444", border: "2px solid hsl(var(--primary))", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 800, color: "white", padding: "0 3px" }}>
                      {unreadCount}
                    </span>
                  )}
                </button>
                <button onClick={() => navigate("/profile")} style={{
                  width: 38, height: 38, borderRadius: 12, background: "rgba(255,255,255,0.18)",
                  border: "2px solid rgba(255,255,255,0.35)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center"
                }}>
                  <User size={18} color="white" />
                </button>
              </div>
            </div>
          </div>

          {/* CONTENT */}
          <div style={{ flex: 1, overflowY: "auto", paddingBottom: 88, marginTop: 12 }}>
            {/* KPI CARDS */}
            <div style={{ padding: "0 14px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {KPI_DATA.map((kpi, i) => {
                const Icon = kpi.icon;
                return (
                  <div key={kpi.label} style={{
                    background: "white", borderRadius: 18, padding: "16px 14px",
                    boxShadow: "0 4px 20px rgba(0,0,0,0.07)",
                    opacity: loaded ? 1 : 0, transform: loaded ? "translateY(0)" : "translateY(18px)",
                    transition: `opacity 0.45s ease-out ${i * 0.08 + 0.15}s, transform 0.45s ease-out ${i * 0.08 + 0.15}s`
                  }}>
                    <div style={{
                      width: 38, height: 38, borderRadius: 11, background: `hsl(${kpi.bg})`,
                      display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10
                    }}>
                      <Icon size={19} style={{ color: `hsl(${kpi.color})` }} />
                    </div>
                    <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted-foreground))", margin: 0 }}>{kpi.label}</p>
                    <p style={{ fontSize: 26, fontWeight: 800, color: "hsl(var(--foreground))", margin: "2px 0 0", lineHeight: 1.1 }}>{kpi.value}</p>
                  </div>
                );
              })}
            </div>

            {/* QUICK ACTIONS */}
            <div style={{ padding: "20px 14px 0" }}>
              <h2 style={{ fontSize: 15, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 10 }}>Ações rápidas</h2>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {[
                  { icon: <PlusCircle size={20} />, label: "Nova solicitação de viagem", desc: "Criar novo pedido", isPrimary: true, onClick: () => setModalView("newTrip") },
                  { icon: <Plane size={18} />, label: "Ver viagens em andamento", desc: `${activeTrips.length} viagens ativas`, onClick: () => setModalView("activeTrips") },
                  { icon: <History size={18} />, label: "Histórico de viagens", desc: "Todas as viagens realizadas", onClick: () => setModalView("history") },
                  { icon: <UserPlus size={18} />, label: "Cadastrar Turista", desc: "Registrar novo turista", onClick: () => setModalView("registerTourist") },
                  { icon: <FileSignature size={18} />, label: "Ver contratos", desc: `${CONTRACTS_PENDING.length} a assinar · ${CONTRACTS_SIGNED.length} assinados`, onClick: () => setShowContracts(true) },
                ].map((action, i) => (
                  <button
                    key={i}
                    onClick={action.onClick}
                    style={{
                      display: "flex", alignItems: "center", gap: 12, padding: "14px 16px", borderRadius: 16,
                      border: (action as any).isPrimary ? "none" : (action as any).isHighlight ? "2px solid hsl(var(--primary))" : "1px solid hsl(var(--border))",
                      background: (action as any).isPrimary ? "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))" : (action as any).isHighlight ? "hsl(var(--matrip-light))" : "white",
                      color: (action as any).isPrimary ? "white" : "hsl(var(--foreground))",
                      cursor: "pointer", boxShadow: (action as any).isPrimary ? "0 6px 20px hsl(var(--primary) / 0.35)" : (action as any).isHighlight ? "0 4px 16px hsl(var(--primary) / 0.15)" : "0 2px 8px rgba(0,0,0,0.04)",
                      textAlign: "left", transition: "transform 0.15s"
                    }}
                    onMouseDown={(e) => (e.currentTarget.style.transform = "scale(0.98)")}
                    onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
                  >
                    <div style={{
                      width: 40, height: 40, borderRadius: 12,
                      background: action.isPrimary ? "rgba(255,255,255,0.2)" : "hsl(var(--matrip-light))",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      color: action.isPrimary ? "white" : "hsl(var(--primary))", flexShrink: 0
                    }}>
                      {action.icon}
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{ fontWeight: 700, fontSize: 13, margin: 0 }}>{action.label}</p>
                      <p style={{ fontSize: 11, opacity: 0.7, margin: "2px 0 0" }}>{action.desc}</p>
                    </div>
                    <ChevronRight size={18} style={{ opacity: 0.5, flexShrink: 0 }} />
                  </button>
                ))}
              </div>
            </div>

            {/* CHART */}
            <div style={{ padding: "20px 14px 0" }}>
              <div className="flex items-center justify-between mb-2">
                <h2 style={{ fontSize: 15, fontWeight: 700, color: "hsl(var(--foreground))" }}>Crescimento de viagens</h2>
                <span style={{
                  fontSize: 11, fontWeight: 700, color: "hsl(155 70% 42%)", background: "hsl(155 70% 93%)",
                  borderRadius: 8, padding: "2px 8px", display: "flex", alignItems: "center", gap: 3
                }}>
                  <ArrowUpRight size={12} /> +47%
                </span>
              </div>
              <div style={{ background: "white", borderRadius: 18, padding: "16px 8px 8px 0", boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}>
                <ResponsiveContainer width="100%" height={160}>
                  <AreaChart data={CHART_DATA}>
                    <defs>
                      <linearGradient id="colorViagens" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(38 85% 42%)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(38 85% 42%)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(214 20% 93%)" vertical={false} />
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "hsl(215 15% 52%)", fontSize: 11, fontWeight: 600 }} />
                    <YAxis hide />
                    <Tooltip
                      contentStyle={{ background: "white", border: "1px solid hsl(214 20% 90%)", borderRadius: 10, fontSize: 12, fontWeight: 600, boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}
                      formatter={(value: number) => [`${value} viagens`, ""]}
                      labelFormatter={(label: string) => `Mês: ${label}`}
                    />
                    <Area type="monotone" dataKey="viagens" stroke="hsl(38 85% 42%)" strokeWidth={2.5} fill="url(#colorViagens)" dot={false} activeDot={{ r: 5, fill: "hsl(38 85% 42%)", stroke: "white", strokeWidth: 2 }} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* RECENT TRIPS */}
            <div style={{ padding: "20px 14px 0" }}>
              <div className="flex items-center justify-between mb-2">
                <h2 style={{ fontSize: 15, fontWeight: 700, color: "hsl(var(--foreground))" }}>Viagens recentes</h2>
                <button onClick={() => setModalView("history")} style={{
                  fontSize: 12, color: "hsl(var(--primary))", fontWeight: 600, background: "none",
                  border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 2
                }}>
                  Ver todas <ChevronRight size={14} />
                </button>
              </div>
              <TripList trips={RECENT_TRIPS} />
            </div>
            <div style={{ height: 16 }} />
          </div>
        </>
      )}

      {/* ─── TRIPS TAB ─── */}
      {activeTab === "trips" && <TripsTab />}

      {/* ─── BOOKINGS TAB ─── */}
      {activeTab === "bookings" && <BookingsTab />}

      {/* ─── PROFILE TAB ─── */}
      {activeTab === "profile" && <ProfileTab />}

      {/* ─── MODALS ─── */}
      <SlidePanel show={modalView === "newTrip"} onClose={() => setModalView(null)} title="Nova Solicitação" subtitle="Viagem" icon={PlusCircle}>
        <NewTripForm />
      </SlidePanel>

      <SlidePanel show={modalView === "registerTourist"} onClose={() => setModalView(null)} title="Cadastrar Turista" subtitle="Novo cadastro" icon={UserPlus}>
        <RegisterTouristForm onClose={() => setModalView(null)} />
      </SlidePanel>

      <SlidePanel show={modalView === "activeTrips"} onClose={() => setModalView(null)} title="Em Andamento" subtitle="Viagens" icon={Plane}>
        <div style={{ padding: "16px" }}>
          <TripList trips={activeTrips} />
        </div>
      </SlidePanel>

      <SlidePanel show={modalView === "history"} onClose={() => setModalView(null)} title="Histórico" subtitle="Viagens" icon={History}>
        <div style={{ padding: "12px 16px 0" }}>
          {/* Filter chips */}
          <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 12 }}>
            {["todos", "pendente", "aprovado", "em andamento", "concluído", "cancelado"].map((f) => (
              <button
                key={f}
                onClick={() => setHistoryFilter(f)}
                style={{
                  padding: "6px 14px", borderRadius: 20, border: "none", cursor: "pointer", whiteSpace: "nowrap",
                  fontSize: 11, fontWeight: 700,
                  background: historyFilter === f ? "hsl(var(--primary))" : "hsl(var(--muted))",
                  color: historyFilter === f ? "white" : "hsl(var(--muted-foreground))",
                  transition: "all 0.2s"
                }}
              >
                {f === "todos" ? "Todos" : (STATUS_STYLES[f]?.label || f)}
              </button>
            ))}
          </div>
          {/* Search */}
          <div style={{
            display: "flex", alignItems: "center", gap: 10, background: "hsl(var(--muted))",
            borderRadius: 12, padding: "0 12px", marginBottom: 12
          }}>
            <Search size={14} style={{ color: "hsl(var(--muted-foreground))" }} />
            <input
              placeholder="Buscar por destino ou passageiro..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ flex: 1, padding: "10px 0", border: "none", background: "transparent", fontSize: 12, color: "hsl(var(--foreground))", outline: "none" }}
            />
          </div>
        </div>
        <div style={{ padding: "0 16px 16px" }}>
          <TripList trips={filteredHistory} />
        </div>
      </SlidePanel>

      {/* ─── CONTRACTS MODAL ─── */}
      {showContracts && (
        <div
          style={{ position: "fixed", inset: 0, zIndex: 100, display: "flex", alignItems: "flex-end", background: "rgba(0,0,0,0.45)" }}
          onClick={() => setShowContracts(false)}
        >
          <div
            style={{
              width: "100%", maxWidth: 480, margin: "0 auto", background: "white",
              borderRadius: "24px 24px 0 0", maxHeight: "82vh", display: "flex", flexDirection: "column", overflow: "hidden"
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{
              background: "linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
              padding: "20px 20px 18px", display: "flex", alignItems: "center", justifyContent: "space-between"
            }}>
              <div className="flex items-center gap-3">
                <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 10, padding: 8, display: "flex" }}>
                  <FileSignature size={20} color="white" />
                </div>
                <div>
                  <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 10, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", margin: 0 }}>Documentos</p>
                  <h3 style={{ color: "white", fontSize: 17, fontWeight: 800, margin: 0 }}>Contratos</h3>
                </div>
              </div>
              <button onClick={() => setShowContracts(false)} style={{ background: "rgba(255,255,255,0.18)", border: "none", borderRadius: 10, padding: 7, cursor: "pointer", display: "flex" }}>
                <X size={18} color="white" />
              </button>
            </div>
            <div style={{ display: "flex", borderBottom: "1px solid hsl(var(--border))", background: "white" }}>
              {[
                { key: "pending", label: "A Assinar", count: CONTRACTS_PENDING.length, color: "45 90% 38%", bg: "45 100% 90%" },
                { key: "signed", label: "Assinados", count: CONTRACTS_SIGNED.length, color: "155 70% 34%", bg: "155 70% 90%" },
              ].map((t) => (
                <button
                  key={t.key}
                  onClick={() => setContractTab(t.key as "signed" | "pending")}
                  style={{
                    flex: 1, padding: "13px 0", border: "none", background: "none", cursor: "pointer",
                    borderBottom: contractTab === t.key ? "2.5px solid hsl(var(--primary))" : "2.5px solid transparent",
                    color: contractTab === t.key ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))",
                    fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", gap: 7, transition: "color 0.2s"
                  }}
                >
                  {t.label}
                  <span style={{
                    fontSize: 10, fontWeight: 800,
                    background: contractTab === t.key ? "hsl(var(--primary))" : `hsl(${t.bg})`,
                    color: contractTab === t.key ? "white" : `hsl(${t.color})`,
                    borderRadius: 20, padding: "1px 7px", transition: "background 0.2s, color 0.2s"
                  }}>
                    {t.count}
                  </span>
                </button>
              ))}
            </div>
            <div style={{ overflowY: "auto", padding: "14px 16px", display: "flex", flexDirection: "column", gap: 10 }}>
              {contractTab === "pending" ? (
                CONTRACTS_PENDING.length === 0 ? (
                  <p style={{ textAlign: "center", color: "hsl(var(--muted-foreground))", padding: "32px 0", fontSize: 14 }}>Nenhum contrato pendente</p>
                ) : (
                  CONTRACTS_PENDING.map((c) => (
                    <div key={c.id} style={{ background: "hsl(45 100% 97%)", border: "1px solid hsl(45 100% 85%)", borderRadius: 16, padding: "14px 16px" }}>
                      <div className="flex items-start justify-between gap-2">
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <p style={{ fontWeight: 700, fontSize: 13, color: "hsl(var(--foreground))", margin: 0 }}>{c.title}</p>
                          <p style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", margin: "3px 0 0" }}>{c.parceiro}</p>
                        </div>
                        <span style={{ fontSize: 10, fontWeight: 700, color: "hsl(45 90% 38%)", background: "hsl(45 100% 88%)", borderRadius: 20, padding: "3px 10px", whiteSpace: "nowrap", flexShrink: 0 }}>A assinar</span>
                      </div>
                      <div className="flex items-center justify-between" style={{ marginTop: 10 }}>
                        <span style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", display: "flex", alignItems: "center", gap: 4 }}>
                          <Clock size={10} /> {c.date}
                        </span>
                        <div className="flex items-center gap-2">
                          <span style={{ fontSize: 12, fontWeight: 800, color: "hsl(var(--foreground))" }}>{c.value}</span>
                          <button
                            onClick={() => c.pdf && setSelectedContract(c)}
                            style={{
                              background: c.pdf ? "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))" : "hsl(var(--muted))",
                              color: c.pdf ? "white" : "hsl(var(--muted-foreground))", border: "none", borderRadius: 10,
                              padding: "6px 14px", fontSize: 11, fontWeight: 700, cursor: c.pdf ? "pointer" : "not-allowed",
                              display: "flex", alignItems: "center", gap: 4
                            }}
                          >
                            <FileBadge size={13} /> Assinar
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )
              ) : (
                CONTRACTS_SIGNED.length === 0 ? (
                  <p style={{ textAlign: "center", color: "hsl(var(--muted-foreground))", padding: "32px 0", fontSize: 14 }}>Nenhum contrato assinado</p>
                ) : (
                  CONTRACTS_SIGNED.map((c) => (
                    <div key={c.id} style={{ background: "hsl(155 70% 97%)", border: "1px solid hsl(155 70% 85%)", borderRadius: 16, padding: "14px 16px" }}>
                      <div className="flex items-start justify-between gap-2">
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <p style={{ fontWeight: 700, fontSize: 13, color: "hsl(var(--foreground))", margin: 0 }}>{c.title}</p>
                          <p style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", margin: "3px 0 0" }}>{c.parceiro}</p>
                        </div>
                        <span style={{ fontSize: 10, fontWeight: 700, color: "hsl(155 70% 34%)", background: "hsl(155 70% 88%)", borderRadius: 20, padding: "3px 10px", whiteSpace: "nowrap", flexShrink: 0 }}>Assinado</span>
                      </div>
                      <div className="flex items-center justify-between" style={{ marginTop: 10 }}>
                        <span style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", display: "flex", alignItems: "center", gap: 4 }}>
                          <CheckCircle2 size={10} /> Assinado em {c.date}
                        </span>
                        <span style={{ fontSize: 12, fontWeight: 800, color: "hsl(var(--foreground))" }}>{c.value}</span>
                      </div>
                    </div>
                  ))
                )
              )}
              <div style={{ height: 8 }} />
            </div>
          </div>
        </div>
      )}

      {/* ─── PDF VIEWER MODAL ─── */}
      {selectedContract && (
        <div style={{ position: "fixed", inset: 0, zIndex: 200, background: "rgba(0,0,0,0.7)", display: "flex", flexDirection: "column" }}>
          <div style={{
            background: "linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
            padding: "14px 16px", display: "flex", alignItems: "center", gap: 12, flexShrink: 0
          }}>
            <button onClick={() => { setSelectedContract(null); setSignConfirm(false); }} style={{ background: "rgba(255,255,255,0.18)", border: "none", borderRadius: 10, padding: 7, cursor: "pointer", display: "flex", flexShrink: 0 }}>
              <X size={18} color="white" />
            </button>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 10, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", margin: 0 }}>Documento</p>
              <p style={{ color: "white", fontSize: 13, fontWeight: 700, margin: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{selectedContract.title}</p>
            </div>
            <a href={selectedContract.pdf!} download style={{ background: "rgba(255,255,255,0.18)", border: "none", borderRadius: 10, padding: 7, cursor: "pointer", display: "flex", textDecoration: "none", flexShrink: 0 }}>
              <Download size={18} color="white" />
            </a>
          </div>
          <div style={{ flex: 1, overflow: "hidden", background: "#525659", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
            <object data={selectedContract.pdf!} type="application/pdf" style={{ width: "100%", height: "100%", border: "none" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16, padding: 32, textAlign: "center" }}>
                <div style={{ width: 64, height: 64, borderRadius: 16, background: "rgba(255,255,255,0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <FileText size={32} color="white" />
                </div>
                <p style={{ color: "white", fontWeight: 700, fontSize: 15, margin: 0 }}>{selectedContract.title}</p>
                <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 13, margin: 0 }}>Visualize o documento antes de assinar</p>
                <a href={selectedContract.pdf!} target="_blank" rel="noopener noreferrer" style={{
                  background: "white", color: "hsl(var(--primary))", fontWeight: 800, fontSize: 13,
                  borderRadius: 12, padding: "12px 24px", textDecoration: "none", display: "flex", alignItems: "center", gap: 8
                }}>
                  <Eye size={16} /> Abrir PDF em nova aba
                </a>
              </div>
            </object>
          </div>
          <div style={{ background: "white", padding: "14px 16px", flexShrink: 0, boxShadow: "0 -4px 20px rgba(0,0,0,0.12)" }}>
            {!signConfirm ? (
              <button onClick={() => setSignConfirm(true)} style={{
                width: "100%", background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))",
                color: "white", border: "none", borderRadius: 14, padding: "14px 0", fontSize: 14, fontWeight: 800,
                cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                boxShadow: "0 6px 20px hsl(var(--primary) / 0.35)"
              }}>
                <PenLine size={17} /> Assinar contrato
              </button>
            ) : (
              <div>
                <p style={{ textAlign: "center", fontWeight: 700, fontSize: 13, color: "hsl(var(--foreground))", margin: "0 0 12px" }}>Confirmar assinatura digital?</p>
                <div className="flex gap-3">
                  <button onClick={() => setSignConfirm(false)} style={{
                    flex: 1, background: "hsl(var(--muted))", color: "hsl(var(--muted-foreground))",
                    border: "none", borderRadius: 12, padding: "12px 0", fontSize: 13, fontWeight: 700, cursor: "pointer"
                  }}>
                    Cancelar
                  </button>
                  <button onClick={() => { addNotification("success", "Contrato assinado", `O contrato "${selectedContract?.title}" foi assinado digitalmente.`); setSelectedContract(null); setSignConfirm(false); setShowContracts(false); }} style={{
                    flex: 2, background: "linear-gradient(135deg, hsl(155 70% 38%), hsl(155 70% 50%))",
                    color: "white", border: "none", borderRadius: 12, padding: "12px 0", fontSize: 13, fontWeight: 800,
                    cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                    boxShadow: "0 4px 14px rgba(0,150,80,0.3)"
                  }}>
                    <CheckCircle2 size={16} /> Confirmar assinatura
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ─── NOTIFICATIONS PANEL ─── */}
      {showNotifications && (
        <div
          style={{ position: "fixed", inset: 0, zIndex: 100, display: "flex", alignItems: "flex-end", background: "rgba(0,0,0,0.45)" }}
          onClick={() => setShowNotifications(false)}
        >
          <div
            style={{
              width: "100%", maxWidth: 480, margin: "0 auto", background: "white",
              borderRadius: "24px 24px 0 0", maxHeight: "85vh", display: "flex", flexDirection: "column",
              overflow: "hidden", animation: "slideUp 0.3s ease-out"
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{
              background: "linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
              padding: "20px 20px 18px", display: "flex", alignItems: "center", justifyContent: "space-between"
            }}>
              <div className="flex items-center gap-3">
                <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 10, padding: 8, display: "flex" }}>
                  <Bell size={20} color="white" />
                </div>
                <div>
                  <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 10, fontWeight: 700, letterSpacing: 1.2, textTransform: "uppercase", margin: 0 }}>Centro de</p>
                  <h3 style={{ color: "white", fontSize: 17, fontWeight: 800, margin: 0 }}>Notificações</h3>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button onClick={markAllRead} style={{
                    background: "rgba(255,255,255,0.18)", border: "none", borderRadius: 10, padding: "6px 12px",
                    cursor: "pointer", fontSize: 10, fontWeight: 700, color: "white"
                  }}>
                    Marcar lidas
                  </button>
                )}
                <button onClick={() => setShowNotifications(false)} style={{ background: "rgba(255,255,255,0.18)", border: "none", borderRadius: 10, padding: 7, cursor: "pointer", display: "flex" }}>
                  <X size={18} color="white" />
                </button>
              </div>
            </div>
            <div style={{ overflowY: "auto", flex: 1 }}>
              {notifications.length === 0 ? (
                <div style={{ textAlign: "center", padding: "60px 20px", display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 56, height: 56, borderRadius: "50%", background: "hsl(var(--muted))", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Bell size={24} style={{ color: "hsl(var(--muted-foreground))", opacity: 0.5 }} />
                  </div>
                  <p style={{ fontSize: 14, fontWeight: 700, color: "hsl(var(--foreground))", margin: 0 }}>Sem notificações</p>
                  <p style={{ fontSize: 12, color: "hsl(var(--muted-foreground))", margin: 0 }}>Você será notificado sobre ações importantes.</p>
                </div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column" }}>
                  {notifications.map((notif) => {
                    const nStyle = NOTIFICATION_ICONS[notif.type];
                    const TypeIcon = notif.type === "success" ? CheckCircle : notif.type === "error" ? XCircle : notif.type === "warning" ? AlertCircle : Bell;
                    return (
                      <div
                        key={notif.id}
                        style={{
                          display: "flex", alignItems: "flex-start", gap: 12, padding: "14px 16px",
                          borderBottom: "1px solid hsl(var(--border))",
                          background: notif.read ? "white" : "hsl(210 90% 98%)",
                          transition: "background 0.2s"
                        }}
                      >
                        <div style={{
                          width: 38, height: 38, borderRadius: 10, background: `hsl(${nStyle.bg})`,
                          display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 2
                        }}>
                          <TypeIcon size={17} style={{ color: `hsl(${nStyle.color})` }} />
                        </div>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                            <p style={{ fontWeight: 700, fontSize: 13, color: "hsl(var(--foreground))", margin: 0, flex: 1 }}>{notif.title}</p>
                            {!notif.read && (
                              <span style={{ width: 8, height: 8, borderRadius: "50%", background: "hsl(var(--primary))", flexShrink: 0 }} />
                            )}
                          </div>
                          <p style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", margin: "3px 0 0", lineHeight: 1.4 }}>{notif.description}</p>
                          <p style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", margin: "4px 0 0", opacity: 0.7 }}>
                            <Clock size={9} style={{ display: "inline", verticalAlign: "middle", marginRight: 3 }} />
                            {formatTime(notif.time)}
                          </p>
                        </div>
                        <button
                          onClick={() => clearNotification(notif.id)}
                          style={{ background: "none", border: "none", cursor: "pointer", padding: 4, flexShrink: 0, marginTop: 2 }}
                        >
                          <X size={14} style={{ color: "hsl(var(--muted-foreground))" }} />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
              <div style={{ height: 16 }} />
            </div>
          </div>
        </div>
      )}

      <div style={{
        position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)",
        width: "100%", maxWidth: 480, background: "white", borderTop: "1px solid hsl(var(--border))",
        display: "flex", alignItems: "center", justifyContent: "space-around",
        padding: "8px 0 18px", zIndex: 50, boxShadow: "0 -4px 24px rgba(0,0,0,0.06)"
      }}>
        {([
          { id: "home", icon: HomeIcon, label: "Home" },
          { id: "trips", icon: Plane, label: "Viagens" },
          { id: "bookings", icon: CalendarCheck, label: "Reservas" },
          { id: "profile", icon: User, label: "Perfil" },
        ] as { id: Tab; icon: typeof HomeIcon; label: string }[]).map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={{
                display: "flex", flexDirection: "column", alignItems: "center", gap: 3,
                background: "none", border: "none", cursor: "pointer",
                color: isActive ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))",
                transition: "color 0.2s", minWidth: 60, position: "relative", padding: "4px 0"
              }}
            >
              {isActive && (
                <span style={{ position: "absolute", top: -8, width: 24, height: 3, borderRadius: 4, background: "hsl(var(--primary))" }} />
              )}
              <Icon size={22} strokeWidth={isActive ? 2.5 : 1.8} />
              <span style={{ fontSize: 10, fontWeight: isActive ? 700 : 500 }}>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Animation keyframes */}
      <style>{`
        @keyframes slideUp {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default HomeScreen;
