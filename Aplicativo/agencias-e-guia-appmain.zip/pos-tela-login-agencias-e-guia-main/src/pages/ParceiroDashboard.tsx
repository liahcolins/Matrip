import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Home as HomeIcon, FileText, Plane, ShoppingBag, DollarSign,
  Bell, User, LogOut, ArrowUpRight, FileCheck2, Tag,
  BarChart2, Edit2, Eye, Trash2, Search, PlusCircle, TrendingUp } from
"lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from
"recharts";
import logoMatrip from "@/assets/logo_matrip.png";

const CHART_DATA = [
{ month: "Out", vendas: 18 },
{ month: "Nov", vendas: 30 },
{ month: "Dez", vendas: 25 },
{ month: "Jan", vendas: 44 },
{ month: "Fev", vendas: 38 },
{ month: "Mar", vendas: 57 }];


const KPI = [
{ label: "Solicitações de viagens", value: 64, icon: FileText, color: "210 90% 56%", bg: "210 90% 94%" },
{ label: "Viagens em andamento", value: 12, icon: Plane, color: "155 70% 42%", bg: "155 70% 92%" },
{ label: "Produtos/serviços vendidos", value: 89, icon: ShoppingBag, color: "270 60% 58%", bg: "270 60% 94%" },
{ label: "Pagamentos a receber", value: "R$ 48K", icon: DollarSign, color: "var(--matrip-accent)", bg: "44 90% 92%" }];


const SALES = [
  { id: 1, product: "Pacote Carolina 7 dias", status: "pago", value: "R$ 8.400" },
  { id: 2, product: "Pacote São luís 10 dias", status: "pendente", value: "R$ 1.200" },
  { id: 3, product: "Pacote Barreirinhas 5 dias", status: "pago", value: "R$ 14.500" },
  { id: 4, product: "Pacote Raposa 1 dia", status: "cancelado", value: "R$ 350" },
  { id: 5, product: "Viagem Tutóia 3 noites", status: "pendente", value: "R$ 2.100" }];


const PRODUCTS = [
  { id: 1, name: "Pacote Carolina 7 dias", status: "ativo", promo: "R$ 7.999" },
  { id: 2, name: "Seguro Viagem São luís", status: "ativo", promo: "R$ 989" },
  { id: 3, name: "Passeio de Barco Raposa", status: "inativo", promo: "R$ 12.900" },
  { id: 4, name: "Pacote São luís - Barreirinhas ", status: "ativo", promo: "R$ 299" }];


const SALE_STATUS: Record<string, {bg: string;text: string;}> = {
  pago: { bg: "155 70% 90%", text: "155 70% 32%" },
  pendente: { bg: "45 100% 88%", text: "38 90% 36%" },
  cancelado: { bg: "0 84% 93%", text: "0 70% 44%" }
};

const PROD_STATUS: Record<string, {bg: string;text: string;}> = {
  ativo: { bg: "155 70% 90%", text: "155 70% 32%" },
  inativo: { bg: "0 0% 90%", text: "0 0% 42%" }
};

type Tab = "home" | "sales" | "products" | "profile";

const ParceiroDashboard = () => {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [salesSearch, setSalesSearch] = useState("");
  const [prodSearch, setProdSearch] = useState("");
  const [loaded, setLoaded] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 80);
    return () => clearTimeout(t);
  }, []);

  const filteredSales = SALES.filter(
    (s) =>
    s.product.toLowerCase().includes(salesSearch.toLowerCase()) ||
    s.status.toLowerCase().includes(salesSearch.toLowerCase())
  );

  const filteredProds = PRODUCTS.filter(
    (p) =>
    p.name.toLowerCase().includes(prodSearch.toLowerCase()) ||
    p.status.toLowerCase().includes(prodSearch.toLowerCase())
  );

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: "hsl(var(--muted))",
        maxWidth: 480,
        margin: "0 auto",
        position: "relative",
        opacity: loaded ? 1 : 0,
        transform: loaded ? "translateY(0)" : "translateY(12px)",
        transition: "opacity 0.5s ease-out, transform 0.5s ease-out"
      }}>
      
      {/* ── HEADER ── */}
      <div
        style={{
          background: "linear-gradient(160deg, hsl(var(--primary)) 0%, hsl(var(--matrip-gradient-end)) 100%)",
          padding: "48px 20px 52px",
          position: "relative",
          overflow: "hidden"
        }}>
        
        <div style={{ position: "absolute", top: -50, right: -50, width: 200, height: 200, borderRadius: "50%", background: "rgba(255,255,255,0.07)" }} />
        <div style={{ position: "absolute", bottom: -30, left: -20, width: 120, height: 120, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />

        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-2.5">
            <img src={logoMatrip} alt="Matrip" className="w-20 h-20 rounded-full bg-white p-2 shadow-md object-contain" />
            <div>
            <span style={{ color: "rgba(255,255,255,0.65)", fontSize: 10, fontWeight: 700, letterSpacing: 1.5, textTransform: "uppercase" }}>Matrip Corporate Parceiros
              </span>
              <h1 style={{ color: "white", fontSize: 19, fontWeight: 700, lineHeight: 1.25, marginTop: 1 }}>Olá, SOLtur!
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              style={{ background: "rgba(255,255,255,0.14)", border: "none", borderRadius: 12, padding: 8, cursor: "pointer", position: "relative" }}>
              
              <Bell size={19} color="white" />
              <span style={{ position: "absolute", top: 5, right: 5, width: 8, height: 8, borderRadius: "50%", background: "#ef4444", border: "2px solid hsl(var(--primary))" }} />
            </button>
            <button
              onClick={() => navigate("/profile")}
              style={{ width: 38, height: 38, borderRadius: 12, background: "rgba(255,255,255,0.18)", border: "2px solid rgba(255,255,255,0.35)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
              
              <User size={18} color="white" />
            </button>
            <button
              onClick={() => navigate("/login")}
              style={{ width: 38, height: 38, borderRadius: 12, background: "rgba(255,255,255,0.18)", border: "2px solid rgba(255,255,255,0.35)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
              
              <LogOut size={16} color="white" />
            </button>
          </div>
        </div>
      </div>

      {/* ── CONTENT ── */}
      <div style={{ flex: 1, overflowY: "auto", paddingBottom: 88, marginTop: -28 }}>

        {/* KPI CARDS */}
        <div style={{ padding: "0 14px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {KPI.map((kpi, i) => {
            const Icon = kpi.icon;
            return (
              <div
                key={kpi.label}
                style={{
                  background: "white", borderRadius: 18, padding: "16px 14px",
                  boxShadow: "0 4px 20px rgba(0,0,0,0.07)",
                  opacity: loaded ? 1 : 0,
                  transform: loaded ? "translateY(0)" : "translateY(18px)",
                  transition: `opacity 0.45s ease-out ${i * 0.07 + 0.1}s, transform 0.45s ease-out ${i * 0.07 + 0.1}s`
                }}>
                
                <div style={{ width: 38, height: 38, borderRadius: 11, background: `hsl(${kpi.bg})`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}>
                  <Icon size={19} style={{ color: `hsl(${kpi.color})` }} />
                </div>
                <p style={{ fontSize: 10, fontWeight: 600, color: "hsl(var(--muted-foreground))", margin: 0, lineHeight: 1.3 }}>{kpi.label}</p>
                <p style={{ fontSize: 22, fontWeight: 800, color: "hsl(var(--foreground))", margin: "4px 0 0", lineHeight: 1.1 }}>{kpi.value}</p>
              </div>);

          })}
        </div>

        {/* QUICK ACTIONS */}
        <div style={{ padding: "20px 14px 0" }}>
          <h2 style={{ fontSize: 15, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 10 }}>Ações rápidas</h2>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {[
            { icon: FileCheck2, label: "Gerenciar Contratos", color: "210 90% 56%", bg: "210 90% 94%", route: "/contratos" },
            { icon: Tag, label: "Ver promoções atuais", color: "155 70% 42%", bg: "155 70% 92%", route: "/promocoes" },
            { icon: ShoppingBag, label: "Atualizar serviços", color: "270 60% 58%", bg: "270 60% 94%", route: "/servicos" },
            { icon: BarChart2, label: "Relatório de vendas", color: "var(--matrip-accent)", bg: "44 90% 92%", route: "/relatorios-parceiro" }].
            map((a, i) => {
              const Icon = a.icon;
              return (
                <button
                  key={i}
                  style={{
                    display: "flex", flexDirection: "column", alignItems: "flex-start",
                    gap: 8, padding: "14px", borderRadius: 16,
                    background: "white", border: "1px solid hsl(var(--border))",
                    cursor: "pointer", boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                    transition: "transform 0.15s"
                  }}
                  onClick={() => navigate(a.route)}
                  onMouseDown={(e) => e.currentTarget.style.transform = "scale(0.97)"}
                  onMouseUp={(e) => e.currentTarget.style.transform = "scale(1)"}>

                  <div style={{ width: 36, height: 36, borderRadius: 10, background: `hsl(${a.bg})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Icon size={18} style={{ color: `hsl(${a.color})` }} />
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: "hsl(var(--foreground))", textAlign: "left", lineHeight: 1.3 }}>{a.label}</span>
                </button>);

            })}
          </div>
        </div>

        {/* CHART */}
        <div style={{ padding: "20px 14px 0" }}>
          <div className="flex items-center justify-between mb-3">
            <h2 style={{ fontSize: 15, fontWeight: 700, color: "hsl(var(--foreground))" }}>Histórico de vendas</h2>
            <span style={{ fontSize: 11, fontWeight: 700, color: "hsl(155 70% 42%)", background: "hsl(155 70% 93%)", borderRadius: 8, padding: "2px 8px", display: "flex", alignItems: "center", gap: 3 }}>
              <ArrowUpRight size={12} /> +32%
            </span>
          </div>
          <div style={{ background: "white", borderRadius: 18, padding: "16px 8px 8px 0", boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}>
            <ResponsiveContainer width="100%" height={150}>
              <AreaChart data={CHART_DATA}>
                <defs>
                  <linearGradient id="colorParc" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(38 85% 48%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(38 85% 48%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(214 20% 93%)" vertical={false} />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "hsl(215 15% 52%)", fontSize: 11, fontWeight: 600 }} />
                <YAxis hide />
                <Tooltip
                  contentStyle={{ background: "white", border: "1px solid hsl(214 20% 90%)", borderRadius: 10, fontSize: 12, fontWeight: 600 }}
                  formatter={(v: number) => [`R$ ${v}K`, ""]}
                  labelFormatter={(l: string) => `Mês: ${l}`} />
                
                <Area type="monotone" dataKey="vendas" stroke="hsl(38 85% 48%)" strokeWidth={2.5} fill="url(#colorParc)" dot={false} activeDot={{ r: 5, fill: "hsl(38 85% 48%)", stroke: "white", strokeWidth: 2 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* SALES TABLE */}
        <div style={{ padding: "20px 14px 0" }}>
          <h2 style={{ fontSize: 15, fontWeight: 700, color: "hsl(var(--foreground))", marginBottom: 10 }}>Tabela de Vendas</h2>
          <div className="flex items-center gap-2 rounded-xl px-3 py-2.5 mb-3 border" style={{ background: "white", borderColor: "hsl(var(--border))" }}>
            <Search size={15} style={{ color: "hsl(var(--muted-foreground))" }} />
            <input
              type="text"
              placeholder="Pesquisar venda..."
              value={salesSearch}
              onChange={(e) => setSalesSearch(e.target.value)}
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              style={{ color: "hsl(var(--foreground))" }} />
            
          </div>
          <div style={{ background: "white", borderRadius: 18, overflow: "hidden", boxShadow: "0 4px 20px rgba(0,0,0,0.06)" }}>
            {filteredSales.map((s, i) => {
              const st = SALE_STATUS[s.status];
              return (
                <div
                  key={s.id}
                  style={{
                    display: "flex", alignItems: "center", padding: "13px 16px", gap: 12,
                    borderBottom: i < filteredSales.length - 1 ? "1px solid hsl(var(--border))" : "none"
                  }}>
                  
                  <div style={{ width: 38, height: 38, borderRadius: 10, background: "hsl(270 60% 94%)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <ShoppingBag size={17} style={{ color: "hsl(270 60% 44%)" }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontWeight: 700, fontSize: 13, color: "hsl(var(--foreground))", margin: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.product}</p>
                    <p style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", margin: "2px 0 0" }}>{s.value}</p>
                  </div>
                  <span style={{ fontSize: 10, fontWeight: 700, color: `hsl(${st.text})`, background: `hsl(${st.bg})`, borderRadius: 20, padding: "3px 9px", whiteSpace: "nowrap", flexShrink: 0 }}>
                    {s.status.charAt(0).toUpperCase() + s.status.slice(1)}
                  </span>
                  <button style={{ background: "hsl(var(--muted))", border: "none", borderRadius: 8, padding: 6, cursor: "pointer", display: "flex", flexShrink: 0 }}>
                    <Eye size={13} style={{ color: "hsl(var(--muted-foreground))" }} />
                  </button>
                </div>);

            })}
            {filteredSales.length === 0 &&
            <p style={{ textAlign: "center", padding: "24px", color: "hsl(var(--muted-foreground))", fontSize: 13 }}>Nenhuma venda encontrada.</p>
            }
          </div>
        </div>

        {/* PRODUCTS TABLE */}
        <div style={{ padding: "20px 14px 0" }}>
          <div className="flex items-center justify-between mb-3">
            <h2 style={{ fontSize: 15, fontWeight: 700, color: "hsl(var(--foreground))" }}>Produtos e Serviços</h2>
            <button
              style={{ display: "flex", alignItems: "center", gap: 4, background: "linear-gradient(135deg, hsl(var(--primary)), hsl(var(--matrip-gradient-end)))", border: "none", borderRadius: 10, padding: "6px 12px", color: "white", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
              
              <PlusCircle size={14} /> Novo
            </button>
          </div>
          <div className="flex items-center gap-2 rounded-xl px-3 py-2.5 mb-3 border" style={{ background: "white", borderColor: "hsl(var(--border))" }}>
            <Search size={15} style={{ color: "hsl(var(--muted-foreground))" }} />
            <input
              type="text"
              placeholder="Pesquisar produto..."
              value={prodSearch}
              onChange={(e) => setProdSearch(e.target.value)}
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              style={{ color: "hsl(var(--foreground))" }} />
            
          </div>
          <div style={{ background: "white", borderRadius: 18, overflow: "hidden", boxShadow: "0 4px 20px rgba(0,0,0,0.06)", marginBottom: 16 }}>
            {filteredProds.map((p, i) => {
              const st = PROD_STATUS[p.status];
              return (
                <div
                  key={p.id}
                  style={{
                    display: "flex", alignItems: "center", padding: "13px 16px", gap: 12,
                    borderBottom: i < filteredProds.length - 1 ? "1px solid hsl(var(--border))" : "none"
                  }}>
                  
                  <div style={{ width: 38, height: 38, borderRadius: 10, background: "hsl(44 90% 92%)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <Tag size={17} style={{ color: "hsl(38 90% 44%)" }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontWeight: 700, fontSize: 13, color: "hsl(var(--foreground))", margin: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.name}</p>
                    <p style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", margin: "2px 0 0" }}>Promo: {p.promo}</p>
                  </div>
                  <span style={{ fontSize: 10, fontWeight: 700, color: `hsl(${st.text})`, background: `hsl(${st.bg})`, borderRadius: 20, padding: "3px 9px", whiteSpace: "nowrap", flexShrink: 0 }}>
                    {p.status.charAt(0).toUpperCase() + p.status.slice(1)}
                  </span>
                  <div className="flex items-center gap-1">
                    <button style={{ background: "hsl(var(--muted))", border: "none", borderRadius: 8, padding: 6, cursor: "pointer", display: "flex" }}>
                      <Edit2 size={13} style={{ color: "hsl(var(--muted-foreground))" }} />
                    </button>
                    <button style={{ background: "hsl(0 84% 95%)", border: "none", borderRadius: 8, padding: 6, cursor: "pointer", display: "flex" }}>
                      <Trash2 size={13} style={{ color: "hsl(0 70% 50%)" }} />
                    </button>
                  </div>
                </div>);

            })}
            {filteredProds.length === 0 &&
            <p style={{ textAlign: "center", padding: "24px", color: "hsl(var(--muted-foreground))", fontSize: 13 }}>Nenhum produto encontrado.</p>
            }
          </div>
        </div>
      </div>

      {/* BOTTOM NAV */}
      <div
        style={{
          position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)",
          width: "100%", maxWidth: 480, background: "white",
          borderTop: "1px solid hsl(var(--border))",
          display: "flex", alignItems: "center", justifyContent: "space-around",
          padding: "8px 0 18px", zIndex: 50,
          boxShadow: "0 -4px 24px rgba(0,0,0,0.06)"
        }}>
        
        {([
        { id: "home", icon: HomeIcon, label: "Home", route: "/parceiro" },
        { id: "sales", icon: ShoppingBag, label: "Vendas", route: "/relatorios-parceiro" },
        { id: "products", icon: Tag, label: "Produtos", route: "/servicos" },
        { id: "profile", icon: User, label: "Perfil", route: "/profile" }] as
        {id: Tab; icon: typeof HomeIcon; label: string; route: string;}[]).map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                navigate(item.route);
              }}
              style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, padding: "4px 14px", background: "none", border: "none", cursor: "pointer" }}>
              
              <div style={{ width: 32, height: 32, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", background: isActive ? "hsl(var(--matrip-light))" : "transparent", transition: "background 0.2s" }}>
                <Icon size={20} style={{ color: isActive ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))", transition: "color 0.2s" }} />
              </div>
              <span style={{ fontSize: 10, fontWeight: isActive ? 700 : 500, color: isActive ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))", transition: "color 0.2s" }}>
                {item.label}
              </span>
            </button>);

        })}
      </div>
    </div>);

};

export default ParceiroDashboard;